package com.dat_management.backend.dto;

import lombok.Data;
import java.util.List;

@Data
public class JapaneseDashboardDTO {

    private List<DeptCertifiedRow> byCertifiedDept;
    private List<TeamLevelRow> byTeam;
    private List<TeamCommRow> byTeamComm;
    private List<CommCapabilityRow> commCapability;
    private List<NoCertMemberRow> noCertMembers;
    private String target1Date;
    private String target2Date;

    @Data
    public static class DeptCertifiedRow {
        private String department;
        private int n1, n2, n3, n4, n5, none, total;
    }

    

    @Data
    public static class TeamLevelRow {
        private String team;
        private int curN1, curN2, curN3, curN4, curN5;
        private int t1N1, t1N2, t1N3, t1N4, t1N5;
        private int t2N1, t2N2, t2N3, t2N4, t2N5;
    }

    @Data
    public static class TeamCommRow {
        private String team;
        private int curL0, curL1G1, curL1G2, curL1G3, curL2G1, curL2G2, curL2G3, curL3;
        private int t1L0, t1L1G1, t1L1G2, t1L1G3, t1L2G1, t1L2G2, t1L2G3, t1L3;
        private int t2L0, t2L1G1, t2L1G2, t2L1G3, t2L2G1, t2L2G2, t2L2G3, t2L3;
    }

    @Data
    public static class CommCapabilityRow {
        private String level;
        private int current, target1, target2;
    }

    @Data
    public static class NoCertMemberRow {
        private String team;
        private int current, target1, target2;
    }
}