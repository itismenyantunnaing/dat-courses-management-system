package com.dat_management.backend.repository;

import com.dat_management.backend.entity.EmployeeJapaneseProfile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
<<<<<<< Updated upstream
=======
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
>>>>>>> Stashed changes

import java.util.Optional;

public interface EmployeeJapaneseProfileRepository extends JpaRepository<EmployeeJapaneseProfile, Integer> {

    Optional<EmployeeJapaneseProfile> findByEmployeeId(String employeeId);
<<<<<<< Updated upstream

    boolean existsByEmployeeId(String employeeId);
}
=======
@Query("""
    SELECT p FROM EmployeeJapaneseProfile p
    JOIN FETCH p.employee e
    LEFT JOIN FETCH e.team t
    LEFT JOIN FETCH e.departmentDir d
    WHERE e.isDeleted = false
""")
List<EmployeeJapaneseProfile> findAllWithEmployee();}

>>>>>>> Stashed changes
