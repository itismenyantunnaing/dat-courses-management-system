package com.dat_management.backend.service;

import com.dat_management.backend.dto.JapaneseDashboardDTO;
import com.dat_management.backend.dto.JapaneseDashboardDTO.*;
import com.dat_management.backend.entity.EmployeeJapaneseProfile;
import com.dat_management.backend.entity.TargetTerm;
import com.dat_management.backend.repository.EmployeeJapaneseProfileRepository;
import com.dat_management.backend.repository.TargetTermRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JapaneseDashboardService {

    private final EmployeeJapaneseProfileRepository profileRepository;
    private final TargetTermRepository targetTermRepository;

    private static final List<String> COMM_FULL_LABELS = List.of(
        "Level 0 | None",
        "Level 1 | G1:Email writing-Chat with DIR and QA/bug/issues reporting using simple words",
        "Level 1 | G2:Email writing-Chat with DIR, QA/bug/issues reporting, Understand requirements/documents with the supports from interpretation tool",
        "Level 1 | G3:Email writing-Chat with DIR, QA/bug/issues reporting, Understand requirements/documents with the supports from interpretation tool, Basic & Internal team daily conversation using simple words",
        "Level 2 | G1:Email reading/writing/MS team chat, Daily team conversation",
        "Level 2 | G2:Email reading/writing/MS team chat, Daily team conversation, Understand/prepare the documents/requirements in Japanese",
        "Level 2 | G3:Email reading/writing/MS team chat, Daily team conversation, Understand/prepare the documents/requirements in Japanese, can Participate/discuss with Japanese Customers",
        "Level 3 | Lead Meeting with DIR/Japanese clients, Handle negotiations, Write formal proposal"
    );

    public JapaneseDashboardDTO buildDashboard() {
        List<EmployeeJapaneseProfile> profiles = profileRepository.findAllWithEmployee();

        TargetTerm targetTerm = targetTermRepository.findAll().stream()
                .filter(t -> Boolean.TRUE.equals(t.getIsActive()))
                .findFirst().orElse(null);

        JapaneseDashboardDTO dto = new JapaneseDashboardDTO();

        if (targetTerm != null) {
            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MMM-yyyy");
            dto.setTarget1Date(targetTerm.getTarget1Date().format(fmt));
            dto.setTarget2Date(targetTerm.getTarget2Date().format(fmt));
        }

        dto.setByCertifiedDept(buildByCertifiedDept(profiles));
        dto.setByTeam(buildByTeam(profiles));
        dto.setByTeamComm(buildByTeamComm(profiles));
        dto.setCommCapability(buildCommCapability(profiles));
        dto.setNoCertMembers(buildNoCertMembers(profiles));

        return dto;
    }

    // ── Section 1: By Department
    private List<DeptCertifiedRow> buildByCertifiedDept(List<EmployeeJapaneseProfile> profiles) {
        Map<String, DeptCertifiedRow> map = new LinkedHashMap<>();

        for (EmployeeJapaneseProfile p : profiles) {
            String dept = deptName(p);
            DeptCertifiedRow row = map.computeIfAbsent(dept, k -> {
                DeptCertifiedRow r = new DeptCertifiedRow(); r.setDepartment(k); return r;
            });
            switch (getCertifiedLevel(p)) {
                case "N1" -> row.setN1(row.getN1() + 1);
                case "N2" -> row.setN2(row.getN2() + 1);
                case "N3" -> row.setN3(row.getN3() + 1);
                case "N4" -> row.setN4(row.getN4() + 1);
                case "N5" -> row.setN5(row.getN5() + 1);
                default   -> row.setNone(row.getNone() + 1);
            }
            row.setTotal(row.getTotal() + 1);
        }

        DeptCertifiedRow total = new DeptCertifiedRow();
        total.setDepartment("Grand Total");
        map.values().forEach(r -> {
            total.setN1(total.getN1() + r.getN1());
            total.setN2(total.getN2() + r.getN2());
            total.setN3(total.getN3() + r.getN3());
            total.setN4(total.getN4() + r.getN4());
            total.setN5(total.getN5() + r.getN5());
            total.setNone(total.getNone() + r.getNone());
            total.setTotal(total.getTotal() + r.getTotal());
        });

        List<DeptCertifiedRow> result = new ArrayList<>(map.values());
        result.add(total);
        return result;
    }

    // ── Section 2: By Team JLPT
    private List<TeamLevelRow> buildByTeam(List<EmployeeJapaneseProfile> profiles) {
        Map<String, TeamLevelRow> map = new LinkedHashMap<>();

        for (EmployeeJapaneseProfile p : profiles) {
            String team = teamName(p);
            if (team.isEmpty()) continue;
            TeamLevelRow row = map.computeIfAbsent(team, k -> {
                TeamLevelRow r = new TeamLevelRow(); r.setTeam(k); return r;
            });
            incrTeamJlpt(row, "cur", getCertifiedLevel(p));
            incrTeamJlpt(row, "t1",  cleanJlpt(p.getTarget1JlptNatLevel()));
            incrTeamJlpt(row, "t2",  cleanJlpt(p.getTarget2JlptNatLevel()));
        }

        TeamLevelRow total = new TeamLevelRow();
        total.setTeam("Grand Total");
        map.values().forEach(r -> sumTeamRow(total, r));

        List<TeamLevelRow> result = new ArrayList<>(map.values());
        result.add(total);
        return result;
    }

    // ── Section 3: By Team Communication
    private List<TeamCommRow> buildByTeamComm(List<EmployeeJapaneseProfile> profiles) {
        Map<String, TeamCommRow> map = new LinkedHashMap<>();

        for (EmployeeJapaneseProfile p : profiles) {
            String team = teamName(p);
            if (team.isEmpty()) continue;
            TeamCommRow row = map.computeIfAbsent(team, k -> {
                TeamCommRow r = new TeamCommRow(); r.setTeam(k); return r;
            });
            incrCommFields(row, "cur", p.getCurrentCommunicationLevel());
            incrCommFields(row, "t1",  p.getTarget1CommunicationLevel());
            incrCommFields(row, "t2",  p.getTarget2CommunicationLevel());
        }

        TeamCommRow total = new TeamCommRow();
        total.setTeam("Grand Total");
        map.values().forEach(r -> sumCommRow(total, r));

        List<TeamCommRow> result = new ArrayList<>(map.values());
        result.add(total);
        return result;
    }

    // ── Section 4: Communication Capability totals
    private List<CommCapabilityRow> buildCommCapability(List<EmployeeJapaneseProfile> profiles) {
        Map<String, int[]> counts = new LinkedHashMap<>();
        COMM_FULL_LABELS.forEach(lbl -> counts.put(lbl, new int[3]));

        for (EmployeeJapaneseProfile p : profiles) {
            String cur = matchCommLabel(p.getCurrentCommunicationLevel());
            String t1  = matchCommLabel(p.getTarget1CommunicationLevel());
            String t2  = matchCommLabel(p.getTarget2CommunicationLevel());
            if (!cur.isEmpty()) counts.get(cur)[0]++;
            if (!t1.isEmpty())  counts.get(t1)[1]++;
            if (!t2.isEmpty())  counts.get(t2)[2]++;
        }

        return counts.entrySet().stream().map(e -> {
            CommCapabilityRow r = new CommCapabilityRow();
            r.setLevel(e.getKey());
            r.setCurrent(e.getValue()[0]);
            r.setTarget1(e.getValue()[1]);
            r.setTarget2(e.getValue()[2]);
            return r;
        }).collect(Collectors.toList());
    }

    // ── Section 5: No Certified Members per Team
    private List<NoCertMemberRow> buildNoCertMembers(List<EmployeeJapaneseProfile> profiles) {
        Map<String, NoCertMemberRow> map = new LinkedHashMap<>();

        for (EmployeeJapaneseProfile p : profiles) {
            String team = teamName(p);
            NoCertMemberRow row = map.computeIfAbsent(team, k -> {
                NoCertMemberRow r = new NoCertMemberRow(); r.setTeam(k); return r;
            });
            boolean notCertified = getCertifiedLevel(p).isEmpty();
            if (notCertified) {
                row.setCurrent(row.getCurrent() + 1);
                if (!isBlankOrNone(p.getTarget1JlptNatLevel())) row.setTarget1(row.getTarget1() + 1);
                if (!isBlankOrNone(p.getTarget2JlptNatLevel())) row.setTarget2(row.getTarget2() + 1);
            }
        }

        NoCertMemberRow total = new NoCertMemberRow();
        total.setTeam("Grand Total");
        map.values().forEach(r -> {
            total.setCurrent(total.getCurrent() + r.getCurrent());
            total.setTarget1(total.getTarget1() + r.getTarget1());
            total.setTarget2(total.getTarget2() + r.getTarget2());
        });

        List<NoCertMemberRow> result = new ArrayList<>(map.values());
        result.add(total);
        return result;
    }

    // ── Increment helpers ─────────────────────────────────────────────────────

    private void incrTeamJlpt(TeamLevelRow row, String prefix, String level) {
        switch (prefix + "_" + level) {
            case "cur_N1" -> row.setCurN1(row.getCurN1() + 1);
            case "cur_N2" -> row.setCurN2(row.getCurN2() + 1);
            case "cur_N3" -> row.setCurN3(row.getCurN3() + 1);
            case "cur_N4" -> row.setCurN4(row.getCurN4() + 1);
            case "cur_N5" -> row.setCurN5(row.getCurN5() + 1);
            case "t1_N1"  -> row.setT1N1(row.getT1N1() + 1);
            case "t1_N2"  -> row.setT1N2(row.getT1N2() + 1);
            case "t1_N3"  -> row.setT1N3(row.getT1N3() + 1);
            case "t1_N4"  -> row.setT1N4(row.getT1N4() + 1);
            case "t1_N5"  -> row.setT1N5(row.getT1N5() + 1);
            case "t2_N1"  -> row.setT2N1(row.getT2N1() + 1);
            case "t2_N2"  -> row.setT2N2(row.getT2N2() + 1);
            case "t2_N3"  -> row.setT2N3(row.getT2N3() + 1);
            case "t2_N4"  -> row.setT2N4(row.getT2N4() + 1);
            case "t2_N5"  -> row.setT2N5(row.getT2N5() + 1);
        }
    }

    private void incrCommFields(TeamCommRow row, String prefix, String rawLevel) {
        int b = commBucket(rawLevel);
        if (b < 0) return;
        switch (prefix) {
            case "cur" -> { switch (b) {
                case 0 -> row.setCurL0(row.getCurL0() + 1);
                case 1 -> row.setCurL1G1(row.getCurL1G1() + 1);
                case 2 -> row.setCurL1G2(row.getCurL1G2() + 1);
                case 3 -> row.setCurL1G3(row.getCurL1G3() + 1);
                case 4 -> row.setCurL2G1(row.getCurL2G1() + 1);
                case 5 -> row.setCurL2G2(row.getCurL2G2() + 1);
                case 6 -> row.setCurL2G3(row.getCurL2G3() + 1);
                case 7 -> row.setCurL3(row.getCurL3() + 1);
            }}
            case "t1" -> { switch (b) {
                case 0 -> row.setT1L0(row.getT1L0() + 1);
                case 1 -> row.setT1L1G1(row.getT1L1G1() + 1);
                case 2 -> row.setT1L1G2(row.getT1L1G2() + 1);
                case 3 -> row.setT1L1G3(row.getT1L1G3() + 1);
                case 4 -> row.setT1L2G1(row.getT1L2G1() + 1);
                case 5 -> row.setT1L2G2(row.getT1L2G2() + 1);
                case 6 -> row.setT1L2G3(row.getT1L2G3() + 1);
                case 7 -> row.setT1L3(row.getT1L3() + 1);
            }}
            case "t2" -> { switch (b) {
                case 0 -> row.setT2L0(row.getT2L0() + 1);
                case 1 -> row.setT2L1G1(row.getT2L1G1() + 1);
                case 2 -> row.setT2L1G2(row.getT2L1G2() + 1);
                case 3 -> row.setT2L1G3(row.getT2L1G3() + 1);
                case 4 -> row.setT2L2G1(row.getT2L2G1() + 1);
                case 5 -> row.setT2L2G2(row.getT2L2G2() + 1);
                case 6 -> row.setT2L2G3(row.getT2L2G3() + 1);
                case 7 -> row.setT2L3(row.getT2L3() + 1);
            }}
        }
    }

    private void sumTeamRow(TeamLevelRow t, TeamLevelRow r) {
        t.setCurN1(t.getCurN1()+r.getCurN1()); t.setCurN2(t.getCurN2()+r.getCurN2());
        t.setCurN3(t.getCurN3()+r.getCurN3()); t.setCurN4(t.getCurN4()+r.getCurN4()); t.setCurN5(t.getCurN5()+r.getCurN5());
        t.setT1N1(t.getT1N1()+r.getT1N1());   t.setT1N2(t.getT1N2()+r.getT1N2());
        t.setT1N3(t.getT1N3()+r.getT1N3());   t.setT1N4(t.getT1N4()+r.getT1N4()); t.setT1N5(t.getT1N5()+r.getT1N5());
        t.setT2N1(t.getT2N1()+r.getT2N1());   t.setT2N2(t.getT2N2()+r.getT2N2());
        t.setT2N3(t.getT2N3()+r.getT2N3());   t.setT2N4(t.getT2N4()+r.getT2N4()); t.setT2N5(t.getT2N5()+r.getT2N5());
    }

    private void sumCommRow(TeamCommRow t, TeamCommRow r) {
        t.setCurL0(t.getCurL0()+r.getCurL0());       t.setCurL1G1(t.getCurL1G1()+r.getCurL1G1());
        t.setCurL1G2(t.getCurL1G2()+r.getCurL1G2()); t.setCurL1G3(t.getCurL1G3()+r.getCurL1G3());
        t.setCurL2G1(t.getCurL2G1()+r.getCurL2G1()); t.setCurL2G2(t.getCurL2G2()+r.getCurL2G2());
        t.setCurL2G3(t.getCurL2G3()+r.getCurL2G3()); t.setCurL3(t.getCurL3()+r.getCurL3());
        t.setT1L0(t.getT1L0()+r.getT1L0());         t.setT1L1G1(t.getT1L1G1()+r.getT1L1G1());
        t.setT1L1G2(t.getT1L1G2()+r.getT1L1G2());   t.setT1L1G3(t.getT1L1G3()+r.getT1L1G3());
        t.setT1L2G1(t.getT1L2G1()+r.getT1L2G1());   t.setT1L2G2(t.getT1L2G2()+r.getT1L2G2());
        t.setT1L2G3(t.getT1L2G3()+r.getT1L2G3());   t.setT1L3(t.getT1L3()+r.getT1L3());
        t.setT2L0(t.getT2L0()+r.getT2L0());         t.setT2L1G1(t.getT2L1G1()+r.getT2L1G1());
        t.setT2L1G2(t.getT2L1G2()+r.getT2L1G2());   t.setT2L1G3(t.getT2L1G3()+r.getT2L1G3());
        t.setT2L2G1(t.getT2L2G1()+r.getT2L2G1());   t.setT2L2G2(t.getT2L2G2()+r.getT2L2G2());
        t.setT2L2G3(t.getT2L2G3()+r.getT2L2G3());   t.setT2L3(t.getT2L3()+r.getT2L3());
    }

    // ── Utility ───────────────────────────────────────────────────────────────

    // JLPT → use jlptHighestLevel, anything else/null → use otherJapaneseLevel
    private String getCertifiedLevel(EmployeeJapaneseProfile p) {
        if (p.getJlptNatTest() == EmployeeJapaneseProfile.JapaneseExamType.JLPT) {
            return cleanJlpt(p.getJlptHighestLevel());
        }
        return cleanJlpt(p.getOtherJapaneseLevel());
    }

    private int commBucket(String raw) {
        if (raw == null || raw.isBlank()) return -1;
        String r = raw.toLowerCase();
        if (r.contains("level 0") || r.contains("none")) return 0;
        if (r.contains("level 1") && r.contains("g1"))   return 1;
        if (r.contains("level 1") && r.contains("g2"))   return 2;
        if (r.contains("level 1") && r.contains("g3"))   return 3;
        if (r.contains("level 2") && r.contains("g1"))   return 4;
        if (r.contains("level 2") && r.contains("g2"))   return 5;
        if (r.contains("level 2") && r.contains("g3"))   return 6;
        if (r.contains("level 3"))                        return 7;
        return -1;
    }

    private String matchCommLabel(String raw) {
        int b = commBucket(raw);
        return b >= 0 ? COMM_FULL_LABELS.get(b) : "";
    }

    private String cleanJlpt(String val) {
        if (val == null || val.isBlank() || val.equalsIgnoreCase("None")) return "";
        String v = val.trim().toUpperCase();
        return v.matches("N[1-5]") ? v : "";
    }

    private String nvl(String val) {
        return (val == null || val.isBlank()) ? "" : val.trim();
    }

    private boolean isBlankOrNone(String val) {
        return val == null || val.isBlank() || val.equalsIgnoreCase("None");
    }

    private String teamName(EmployeeJapaneseProfile p) {
        return p.getEmployee().getTeam() != null
                ? p.getEmployee().getTeam().getTeamName() : "";
    }

    private String deptName(EmployeeJapaneseProfile p) {
        return p.getEmployee().getDepartmentDir() != null
                ? p.getEmployee().getDepartmentDir().getDeptName() : "Unknown";
    }
}